package com.example.attrape_moi_si_tu_peux.Model;

public class Cactus extends Vegetal {

    public  Cactus() {
        super(- 1);
    }
}
