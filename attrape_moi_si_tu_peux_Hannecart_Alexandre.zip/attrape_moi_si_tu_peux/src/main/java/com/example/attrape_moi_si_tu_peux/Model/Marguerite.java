package com.example.attrape_moi_si_tu_peux.Model;

public class Marguerite extends Vegetal{
    public Marguerite() {

        super(2);
    }
}
