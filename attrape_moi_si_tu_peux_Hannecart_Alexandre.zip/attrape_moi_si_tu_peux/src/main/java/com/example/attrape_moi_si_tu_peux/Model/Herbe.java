package com.example.attrape_moi_si_tu_peux.Model;

public class Herbe extends Vegetal{
    public Herbe() {
        super(0);
    }
}
