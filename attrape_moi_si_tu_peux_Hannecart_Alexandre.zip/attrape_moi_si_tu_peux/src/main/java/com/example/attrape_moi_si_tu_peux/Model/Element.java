package com.example.attrape_moi_si_tu_peux.Model;

public class Element {
   private Case laCase;
   public Element(){
       super();
   }
}
