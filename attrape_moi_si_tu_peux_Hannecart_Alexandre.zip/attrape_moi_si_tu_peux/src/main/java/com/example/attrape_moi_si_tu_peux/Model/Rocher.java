package com.example.attrape_moi_si_tu_peux.Model;

public class Rocher extends Element {
    public Rocher() {
        super();
    }
}
